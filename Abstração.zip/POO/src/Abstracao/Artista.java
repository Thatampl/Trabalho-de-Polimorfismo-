package Abstracao;

abstract class Artista {
	protected String nome;
	protected int idade;
	protected String tipoArte;

	public Artista() {
	}

	public void Artista() {
		this.nome = nome;
		this.idade = idade;
		this.tipoArte = tipoArte;
	}

	public void dormir() {
		System.out.println(" ZZz...");
	}

	public void chorar() {
		System.out.println(" :( ");
	}
	
	abstract String criarObra();

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getTipoArte() {
		return tipoArte;
	}

	public void setTipoArte(String tipoArte) {
		this.tipoArte = tipoArte;
	}

}
