package Abstracao;

public class Pintor extends Artista{
	@Override
	String criarObra() {
		return "O pintor pintou uma nova obra!";
	}

}
