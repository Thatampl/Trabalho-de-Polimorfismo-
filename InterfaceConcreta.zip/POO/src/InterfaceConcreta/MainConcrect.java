package InterfaceConcreta;

public class MainConcrect {

	public static void main(String[] args) {
		Cachorro cachorro = new Cachorro();
		cachorro.comer();        
	    cachorro.fazerBarulho();

	}

}
