package InterfaceConcreta;

public interface FazerBarulho {
	void fazerBarulho();
	
}
