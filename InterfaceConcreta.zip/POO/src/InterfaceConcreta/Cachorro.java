package InterfaceConcreta;

public class Cachorro implements Comer, FazerBarulho {
	@Override
	public void comer() {
		System.out.println("O cachorro está comendo!");
	}
	@Override
	public void fazerBarulho() {
		System.out.println("O cachorro está latindo: Au, au!");
	}

}
