package InterfaceConcreta;

public interface Comer {
	void comer();

}
