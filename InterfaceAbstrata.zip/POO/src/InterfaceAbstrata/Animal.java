package InterfaceAbstrata;

abstract class Animal implements Comer, FazerBarulho{
	public void comer() {
        System.out.println("O animal está comendo!");
    }
	
}
