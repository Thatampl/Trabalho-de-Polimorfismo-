package InterfaceAbstrata;

public interface FazerBarulho {
	void fazerBarulho();

}
