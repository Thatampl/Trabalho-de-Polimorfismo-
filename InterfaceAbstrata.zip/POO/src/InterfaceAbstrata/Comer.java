package InterfaceAbstrata;

public interface Comer {
	void comer();

}
