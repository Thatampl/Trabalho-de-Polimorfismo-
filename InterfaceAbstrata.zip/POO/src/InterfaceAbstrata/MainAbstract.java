package InterfaceAbstrata;

public class MainAbstract {

	public static void main(String[] args) {
		Gato gato = new Gato();
        gato.comer();         
        gato.fazerBarulho();

	}

}
