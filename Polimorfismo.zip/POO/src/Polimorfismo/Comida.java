package Polimorfismo;

public class Comida {
	public void preparar() {
        System.out.println("Preparando a comida.");
	}
}
