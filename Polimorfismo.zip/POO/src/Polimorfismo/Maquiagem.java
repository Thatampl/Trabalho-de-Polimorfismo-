package Polimorfismo;

public class Maquiagem {
	public void aplicar(String cor) {
		System.out.println("Aplicando batom: " + cor);
    }
	
    public void aplicar(int quant) {
        System.out.println("Aplicando " + quant + " gramas de base.");
    }
    
    public void aplicar(String cor, int quant) {
        System.out.println("Aplicando " + quant + " gramas de base e batom: " + cor);
    }
}
