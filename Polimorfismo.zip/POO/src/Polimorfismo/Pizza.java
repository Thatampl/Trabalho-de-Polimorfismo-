package Polimorfismo;

public class Pizza extends Comida{
	 @Override
	    public void preparar() {
	        System.out.println("Preparando a pizza: colocando a massa, o molho e o queijo.");
	    }
}
