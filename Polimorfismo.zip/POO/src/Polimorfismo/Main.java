package Polimorfismo;

public class Main {
	public static void main(String[] args) {
		
		//Main da classe Maquiagem
		System.out.println("***INFORMAÇÕES DE MAQUIAGEM:***");
		Maquiagem m = new Maquiagem();
		m.aplicar("vermelho");
	    m.aplicar(5);
	    m.aplicar("Rosa", 3);
	   
	    //Main da classe Comida
	    System.out.println("\n***INFORMAÇÕES DE COMIDA:***");
	    Comida comida1 = new Pizza();
	    Comida comida2 = new Sushi();

	    comida1.preparar();  
	    comida2.preparar();  
	  }
 }
