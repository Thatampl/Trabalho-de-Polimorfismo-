package Polimorfismo;

public class Sushi extends Comida {
	@Override
    public void preparar() {
        System.out.println("Preparando o sushi: cozinhando o arroz e enrolando com o peixe.");
    }
}
